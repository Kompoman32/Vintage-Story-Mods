# v1.7.5 - 2025-12-25 - Fixed Recipes

## Bugfixes

* #86 - Fix Nadiyan shepherd boots recipe to not use tailor-only leather bundles


# v1.7.4 - 2025-11-09 - Fixed Recipes

## Compatibility With Other Mods

* #85 - Fix recipe for merchant pants from woolen cloth (needs dark green, too)
* #85 - Wool & More: Add some barber surgeon variants with wool

## Tweaking

* #85 - Tweak recipe ingredients to better match item colors:
  + hunter leggings are more gray than plain
  + squire shirt needs darker blue thread
  + squire pants need red leather (was: red cloth)
  + barber surgeon shirt needs white twine (was: blue twine)
  + aristocrat leggings need yellow/orange leather (was: plain leather)
  + deep noble leggings need red leather (was: red cloth)
  + noble leggings need more cloth and pink thread (was red thread)
  + Nadiyan innkeeper belt needs brass buttons (was: zinc buttons)
  + King coat needs purple leather (was: purple cloth)
  + King pants need dark-red leather, gilded thread and white leather (was: purple cloth, yellow thread)
  + Lackey breeches need dark green and pink cloth (was: green and purple)


# v1.7.3 - 2025-10-18 - Fixed Typos

## Bugfixes

* #84 - Fix typo `stury` in blacksmith apron recipe
* #83 - Nadiyan fisher pants recipe could not be disabled (Thanx, Emporer Q!)


# v1.7.2 - 2025-10-12 - Tinkerers & Blacksmiths

## New Features

* #80 - All alchemist recipes can also be crafted by tinkerers
* #54 - Add more recipes for various Nadiyan worker outfits and masks

## Bugfixes

* #81 - Disabling Nadiyan clothes did not disable Nadiyan wool variant recipes (Thanx, Emperor Q!)

## Balancing and Tweaking

* #82 - Make blacksmith hood a bit cheaper, also craftable by tinkerers


# v1.7.1 - 2025-09-11 - Tweaks

## Bugfixes

* #78 - Some recipes consumed shears by accident

## Compatibility With Other Mods

* #79 - Add over 30 more wool recipe variants for Nadiyan clothing

## New Features

* #75 - Add recipes for all Nadiyan beekeeper items
* #54 - Add recipes for various Nadiyan tunics and hoods
* Nadiyan recipes are now 86% (146 of 170) complete.


# v1.7.0 - 2025-09-04 - More Recipes

## Compatibility

* Require Tailor's Delight 2.0.0 or newer
* Require Expanded Matter 3.3.0 or newer
* Requires VS 1.21.0 or newer

## Compatibility With Other Mods

* Shepherd pants recipe aligned with the wool variant

## Compatibility With VS 1.21

* #73: Fix recipe error due to VS 1.21 moving Alchemist capelet from upperbodyover to shoulder

## New Features

* #76 - Add more recipes for Nadiyan shepherd and peasant clothes
* #74 - Add more recipes for Nadiyan hunter clothes
* Add compatibility recipe for embroidered coif with wool
* Nadiyan recipes are now 79% (135 of 170) complete.

## Balancing and Tweaking

* #74 - Nadiyan hunter clothes can also be crafted by anyone with the bowyer trait
* Use some of the new dark checkered cloth from Tailor's Delight in Nadiyan recipes


# v1.6.0 - 2025-05-24 - More Everything

## Compatibility

* Require Tailor's Delight 1.9.5 or newer

## New Features

* Add recipe for brown skirt
* #54 - Add 65 more recipes for Nadiyan clothes and belts
  * Nadiyan recipes are now 61% (104 of 170) complete.

## Compatibility With Other Mods

* #70 - Add some Nadiyan clothing recipe alternatives for Wool & More

## Translations

* #72 - Add French translation (Thanx, Wailwolf!)
* #71 - Add Russian translation (Thanx, Morok!)


# v1.5.2 - 2025-03-29 - More Recipes

## Compatibility

* Require VS 1.20.6 or newer
* Require Expanded Matter 3.2.0 or newer
* Require Tailor's Delight 1.9.3 or newer

## Bugfixes

* #69 - Config lib patches were partly broken
* #67 - Recipe fix for huntsman tunic and hunter cloak

## Balancing and Tweaking

* #68 - Use emerald buttons in more recipes

## New Features

* #70 - Add some class clothing recipe alternatives for Wool & More
* #62 - Add more config options: disable/enabled Nadiyan recipes, Disable/Enabled Wool alternatives


# v1.5.1 - 2025-01-26 - Less Leather Types

## Compatibility

* #66 - Use replacement leather bundles for Tailor's Delight 1.8.1 removed ones


# v1.5.0 - 2025-01-20 - VS 1.20

## New Features

* #64 - Miner clothes can be crafted by anyone with the "hardy" trait like Blackguards
* #56 - Add missing recipe for noble and royal fur collar
* #54 - Add recipes for Nadiyan aprons, belts, boots & shoes, gloves and shirts

## Compatibility

* #59 - Fix clothing patches for 1.20
* #57 - Remove compatibility for Hide & Fabric (use Wool & More and Hunter's Lodge instead)
* #53 - Fixes for VS 1.20

## Translations

* #48 - Add Latin American Spanish translation (Thank you, Ruddi!)

## Balancing and Tweaking

* #65 - Use dark cloth and twine in recipes
* #60 - Use sturdy leather for sturdy and heavy leather items
* #60 - Nadiyan recipes use nadiyan leather as ingredient


# v1.4.0 - 2024-08-06 - Lost Recipes

## New Features

* #44 - Add more missing recipes for VS clothing (Thanx, anyanana!):
  - aristocrat leggings
  - barber surgeon handwraps
  - blackguard leggings
  - noble fillet
  - tailor blouse
  - tailor jacket
  - hunter leggings
  - woolen leggings (only with Hide & Fabric)

## Balancing and Tweaking

* #46 - Tweak pastoral pants with wool/cotton to include leather
* #45 - Tweak barber surgeon pants recipe to better match colors


# v1.3.1 - 2024-07-01 - Gilded Threads

## New Features

* #43 - Add recipe for deep noble leggings
* #42 - Use silver twine in recipes
* #41 - Replace gold nuggets with gilded (golden) twine in recipes


# v1.3.0 - 2024-07-22 - Warm Clothes

## New Features

* #40 - Add recipe for noble shirt
* #39 - Add recipe for pearl shirt
* #37 - Add recipe for prince breeches
* #36 - Add recipe for gem encrusted fur hat
* #35 - Add recipe for embroidered coif
* #34 - Add recipe for hunter shirt
* #33 - Add warmth to more vanilla craftable clothing items

## Balancing and Tweaking

* #30 - Increase buying prices for some expensive clothing items

## Compatibility With Other Mods

* #38 - Add compatibility with Geology Addons (use Ruby in crafting)


# v1.2.1 - 2024-07-02 - Thick Leather

## Balancing and Tweaking

* #32 - Replace thin leather with plain leather in crafting recipes


# v1.2.0 - 2024-06-18 - Hide and Fabric

## Balancing and Tweaking

* #21 - Shepherd clothing and sandals are now craftable by anyone

## New Features

* #20 - Add recipe for Merchant shirt
* #19 - Add config setting to disable Hide and Fabric recipes for VS clothing

## Compatibility With Other Mods

* #16 - Add 78 more VS clothing recipes based on Hide & Fabric cotton & wool


# v1.1.0 - 2024-06-05 - Stay Warm

## New Features

* #18 - Some leather boots use leather strips instead of twine
* #17 - Add commoner over coat recipe
* #13 - Add clockmaker wristguard recipe

## Bugfixes

* #13 - Fix clockmaker apron "tinker trait" recipe variant display

## Translations

* #9 - Add Japanese translation (Thank you, Macoto Hino!)

## Compatibility With Other Mods

* #14 - Add more VS fur clothing recipes based on Hide & Fabric hide
* #13 - Compatibility with Beltcraft
* #8 - Add more VS clothing recipes based on Hide & Fabric wool


# v1.0.0 - 2024-05-24 - Dresses to Kill

## New Features

* #4 - Add config lib support: Enable/disable recipes via config file
       Needs at least config lib 1.3.13 to work properly
* #3 - Add 105 recipes for VS generic clothing items
* #2 - Add 72 recipes for 41 unique VS class specific clothing items

## Compatibility With Other Mods

* #5 - Add recipes for Shepherd clothing using Hide & Fabric wool

