This mod would have not been possible without the help of countless other people. We stand on the shoulders of giants!

Thank you,

~Tels & Phiwa

## Thank you

First and foremost a big thank you goes to **Saraty**, **Tyron** and all the other
team members for creating such a great game!

### Testing, Feedback and Bugreporting

### Translators

* French: **Wailwolf**
* German: **Tels**, **Phiwa**
* Japanese: **Macoto Hino**
* Latin American Spanish: **Ruddi**
* Russian: **Morok**

### Modding help

* All the people answering questions, on the modding-help discord channel or elsewere: You are awesome!
Especially:
  + **JapanHasRice**
  + **l33tmaan** - Esp. for texturing help and feedback <3
  + **pizza2004** - You are a legend!
  + **Maltiez**
  + **SpearAndFang**

### Resources

The mod icon and title card image are based on generations from [Perchance](https://perchance.org/ai-pixel-art-generator)

