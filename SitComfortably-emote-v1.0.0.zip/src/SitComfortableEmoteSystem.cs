using System;
using System.Collections.Generic;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.Common.Entities;

[assembly: ModInfo("Sit Comfortably (Emote)",
    Description = "Teehee",
    Authors = new[] { "Kompoman32" })]

namespace SitComfortableEmote {
    public class SitComfortableEmoteSystemMod : ModSystem {

        private ICoreClientAPI capi;
        public override bool ShouldLoad(EnumAppSide forSide) {
            return forSide == EnumAppSide.Client;
        }

        public override void StartClientSide(ICoreClientAPI api) {
            base.StartClientSide(api);
            capi = api;

            api.ChatCommands.GetOrCreate("sitcomfy")
            .RequiresPlayer()
            .HandleWith(SitComfy);
        }

        private TextCommandResult SitComfy(TextCommandCallingArgs Args) {
            EntityPlayer Player = Args.Caller.Player.Entity as EntityPlayer;

            if (Player != null)
            {
                if (Player.AnimManager.IsAnimationActive("sitflooridlecomfy"))
                {
                    Player.AnimManager.StopAnimation("sitflooridlecomfy");    
                }
                else
                {
                    Player.AnimManager.StartAnimation("sitflooridlecomfy");    
                }   
            }

            return TextCommandResult.Success(null);
        }
    }
}