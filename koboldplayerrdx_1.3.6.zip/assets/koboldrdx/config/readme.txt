[
"If you are trying to patch one of Maltiez' mods (like Combat Overhaul) for your own model, this folder's patches are only useful for armors.  If you need to adjust animations, copy the structure shown in the animations folder, under config.  His mods utilize a proprietary format for storing animation data separately from the player, which can also be created using a tool he created.  See the Mod DB page for Overhaul Lib for more details.  You will need to use the dev version of overhaul lib to create / edit animations.  Contact him on the official VS discord if you need a new version, he only updates the dev version when asked.",

"https://mods.vintagestory.at/overhaullib"
]