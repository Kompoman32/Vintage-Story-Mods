﻿using Ladder.Blocks;
using Vintagestory.API.Common;

namespace Ladder
{
    public class LadderModSystem : ModSystem
    {
        public override void Start(ICoreAPI api)
        {
            base.Start(api);
            api.RegisterBlockClass("ladder", typeof(BlockLadder));
        }
    }
}
